<!doctype html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
  </head>
  <body class="bg-cyan-100 flex items-center justify-center min-h-screen">

<?php 
$bilangan1 ="";
$bilangan2 ="";
$operator ="";


if (isset($_POST['hitung'])) {
  $bilangan1 = $_POST['bil1'];
  $bilangan2 = $_POST['bil2'];
  $operator = $_POST['operator'];


  switch ($operator) {
    case '+':
      $hasil = $bilangan1 + $bilangan2;
      break;
    case '-':
      $hasil = $bilangan1 - $bilangan2;
      break;
    case '*':
      $hasil = $bilangan1 * $bilangan2;
      break;
    case '/':
      $hasil = $bilangan1 / $bilangan2;
      break;
    default:
      $hasil = "Operator tidak ditemukan";
      break;
  }
}



?>



    <div class="bg-white p-8 rounded-lg shadow-lg w-95">
    <h2 class="text-2x1 font-semibold text-center mb-4">kalkulator</h2>

    <form action="" method="post" class="space-y-4">
      <input type="text" name="bil1" 
      class="w-full p-3 mb-4 border border-gray-300 rounded-lg"off" placeholder="Masukkan bilangan pertama"  />

      <input type="text" name="bil2"
      class="w-full p-3 mb-4 border border-gray-300 rounded-lg"off" placeholder="Masukkan bilangan kedua"  />


      <select name="operator" class="w-full p-3 mb-4 border border-gray-300 rounded-lg">
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="*">*</option>
        <option value="/">/</option>

        <input type="submit" name="hitung" value="Hitung" value="Hitung" class="w-full p-3 bg-blue-500 text-white rounded-lg hover:bg-violet-600 mb-4"  />


        <input type="text" name="hasil" 
        class="w-full p-3 mb-3 border border-gray-300 rounded-lg mb-2 " autocomplete="off" placeholder="Hasil bilangan" readonly value="<?php echo $hasil;?>" />

    </form>
    
  </body>
</html>