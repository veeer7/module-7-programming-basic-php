<!doctype html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
  </head>
  <body class='bg-gray-100 flex items-center justify-center min-h-screen'>

    <?php
    $nama="";
    $hasil="";
    $status="";
    $nilaitugas="";
    $nilai="";
    $nilaiuts = "";
    $nilaiuas = "";



    if(isset ($_POST["hitung"])) { 
        $nama = $_POST['nama'];
        $nilaitugas = $_POST['tugas'];
        $nilaiuts = $_POST['uts'];
        $nilaiuas = $_POST['uas'];
    
        $nilai = $_POST['hitung'];

        $hasil = ((30/100)*$nilaitugas) + ((30/100)*$nilaiuts) + ((40/100)*$nilaiuas);

        switch ($nilai) {
            case $hasil >= 80:
                $status = "A";
                break;
            case $hasil >= 70:
                $status = "B";
                break;
            case $hasil >= 60:
                $status = "C";
                break;
            case $hasil >= 50:
                $status = "D";
                break;
            default:
                $status = "E";
                break;
        }



    }

    

    ?>

    <div class='bg-white p-8 rounded-lg w-100'>
    <h2 class='text-2xl font-semibold pb-3 text-center'>Daftar nilai siswa</h2>
    <form action="" method="POST">

    <input type="text" name="nama" class="w-full p-3 mb-3 border border-gray-300 rounded-md" autocomplete="off" placeholder="Masukan nama" value="<?php echo $nama ?>">
    <input type="number" name="tugas" class="w-full p-3 mb-3 border border-gray-300 rounded-md" autocomplete="off" placeholder="Nilai harian" value="<?php echo $nilaitugas ?>">
    <input type="number" name="uts" class="w-full p-3 mb-3 border border-gray-300 rounded-md" autocomplete="off" placeholder="Nilai uts" value="<?php echo $nilaiuts ?>">
    <input type="number" name="uas" class="w-full p-3 mb-3 border border-gray-300 rounded-md" autocomplete="off" placeholder="Nilai uas" value="<?php echo $nilaiuas ?>">
    <input type="submit" name="hitung" value="hitung" class="w-full p-3 bg-violet-600 rounded-md text-xl font-semibold text-white hover:bg-violet-700 mb-3">
    </form>
    </div>

`<table class="table-fixed border border-black w-100">
  <thead class="border border-black">
    <tr class="bg-black text-white">
      <th>Nama</th>
      <th>Nilai</th>
      <th>Status</th>
      <th>Tugas</th>
      <th>UTS</th>
      <th>UAS</th>
    </tr>
  </thead>
  <tbody>
    <tr class="border border-black text-center">
      <td class="border border-black"><?php echo $nama ?></td>
      <td class="border border-black"><?php echo $hasil ?></td>
      <td class="border border-black"><?php echo $status ?></td>
      <td class="border border-black"><?php echo $nilaitugas ?></td>
      <td class="border border-black"><?php echo $nilaiuts ?></td>
      <td class="border border-black"><?php echo $nilaiuas ?></td>
    </tr>
  </tbody>
</table>
    
  </body>
</html>
